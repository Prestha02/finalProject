from django.contrib import admin
from main.models import Post, Event 

admin.site.register(Post)
admin.site.register(Event)
